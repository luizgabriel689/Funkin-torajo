--Create with TieGuo's Lua Stage Editor
function onCreate()
makeLuaSprite('studio', 'studio', -240, -180)
addLuaSprite('studio', false)
scaleObject('studio', 1, 1)
setScrollFactor('studio', 1, 1)
end