function onCreatePost()
    -- Aumenta o tamanho da barra de vida
    setProperty('healthBar.scale.y', 2) -- Faz a barra ficar mais grossa (mude o número para ajustar)

    -- Personaliza a cor da barra (opcional)
    setHealthBarColors('FF0000', '0000FF') -- Vermelho para o BF, Azul para o oponente

    -- Adiciona um brilho na barra (simula efeito bonito)
    setProperty('healthBar.alpha', 0.9) -- Deixa a barra mais visível com um leve brilho
end