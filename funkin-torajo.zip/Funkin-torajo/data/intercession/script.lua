function onCreate()
    -- Deixa o Torajo preto no início
    setProperty('dad.color', getColorFromHex('000000')) 
end

function onUpdate(elapsed)
    -- Verifica o tempo da música
    if getSongPosition() >= 27000 then -- 27 segundos em milissegundos
        setProperty('dad.color', getColorFromHex('FFFFFF')) -- Volta à cor normal
    end
end